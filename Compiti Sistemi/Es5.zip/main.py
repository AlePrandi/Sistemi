from machine import Pin, ADC, PWM
from utime import sleep

led = PWM(Pin(4, Pin.OUT))
adc = ADC(Pin(26,))

led.freq(5000)
led.duty_u16(0)

while True:
  valore = adc.read_u16()
  led.duty_u16(valore)
