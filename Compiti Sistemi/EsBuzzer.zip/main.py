from machine import Pin, ADC, PWM
from utime import sleep

Buzz = PWM(Pin(5, Pin.OUT))
adc = ADC(Pin(26))

Buzz.freq(5000)
Buzz.duty_u16(0)

while True:
  valore = adc.read_u16()
  Buzz.duty_u16(valore)
