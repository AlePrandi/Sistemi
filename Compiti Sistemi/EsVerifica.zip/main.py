from machine import Pin, ADC
from utime import sleep

TUTTI = 2
T = 0.5

led1 = Pin(6, Pin.OUT)
led2 = Pin(7, Pin.OUT)
led3 = Pin(8, Pin.OUT)
led4 = Pin(9, Pin.OUT)
Button = Pin(0, Pin.IN, Pin.PULL_UP)
adc = ADC(0)

conv_fact = 3.3 / (1 << 12)

while True:

  valore = adc.read_u16()
  ris = valore * conv_fact / 15
  tempo = 3.5 - ris + 0.2

  led1.off()
  led2.off()
  led3.off()
  led4.off()

  if Button.value() == 0:
    sleep(TUTTI)
    led1.on()
    sleep(tempo)
    led1.off()
    led2.on()
    sleep(tempo)
    led2.off()
    led3.on()
    sleep(tempo)
    led3.off()
    led4.on()
    sleep(tempo)
    led4.off()
    sleep(tempo)
    led1.on()
    led2.on()
    led3.on()
    led4.on()
    sleep(TUTTI)

