from machine import Pin, ADC
from utime import sleep

TENS = 3.3

adc = ADC(4)

conv_fact = TENS / (1 << 12)

print("Lettura temperatura interna.\n")

while True:
  result = adc.read_u16() * conv_fact
  temp = 27.0 - (result - 0.706) / 0.001721
  print("Temperatura: {} °C".format(temp))
  sleep(1)