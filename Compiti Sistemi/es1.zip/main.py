from machine import Pin
from utime import sleep

print("Hello, Pi Pico!")

led = Pin(25, Pin.OUT)
while True:
  led.on()
  print("Led acceso")
  sleep(1)
  led.off()
  sleep(1)