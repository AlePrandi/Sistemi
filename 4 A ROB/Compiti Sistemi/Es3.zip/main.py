from machine import Pin
from utime import sleep

RITARDO = 0.02
ledR = Pin(13, Pin.OUT)
ledG = Pin(14, Pin.OUT)
ledV = Pin(15, Pin.OUT)
Button = Pin(3, Pin.IN, Pin.PULL_UP)
cont = 0

while True:

  if Button.value() == 0:
    cont = cont + 1
    sleep(0.3)

  else:
    if cont == 1:
        ledV.on()
        sleep(RITARDO)
        ledG.off()
        sleep(RITARDO)
        ledR.off()
        sleep(RITARDO)

    if cont == 2:
        ledV.off()
        sleep(RITARDO)
        ledG.on()
        sleep(RITARDO)
        ledR.off()
        sleep(RITARDO)
    
    if cont == 3:
        ledV.off()
        sleep(RITARDO)
        ledG.off()
        sleep(RITARDO)
        ledR.on()
        sleep(RITARDO)
        cont = 0
