from machine import Pin
from utime import sleep

T = 1
D = 0.3
TD = T * (1 - D)
TU = T * D

led = Pin(4, Pin.OUT)
while True:
  led.on()
  sleep(TU)
  led.off()
  sleep(TD)