from machine import Pin
from utime import sleep

ledR = Pin(15, Pin.OUT)
ledG = Pin(14, Pin.OUT)
ledV = Pin(13, Pin.OUT)
Norm = Pin(3, Pin.IN, Pin.PULL_UP)
Man = Pin(4, Pin.IN, Pin.PULL_UP)
RITARDO = 0.5

while True:
  if Norm.value() == 0:
    sleep(RITARDO)
    ledR.off()
    ledG.on()
    ledV.off()
    sleep(RITARDO)
    ledR.on()
    ledG.off()
    ledV.off()
    sleep(3)
    ledR.off()

  else:
    if Man.value() == 0:
      ledR.off()
      ledG.off()
      ledV.off()
      sleep(0.25)
      ledG.toggle()
      sleep(0.25)

    else:
      ledR.off()
      ledG.off()
      ledV.on()
