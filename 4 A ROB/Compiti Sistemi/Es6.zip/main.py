from machine import Pin, ADC
from utime import sleep

DIM = 7
TENS = 3.3

adc = ADC(Pin(26))

Led = [
Pin(0, Pin.OUT), 
Pin(1, Pin.OUT),
Pin(2, Pin.OUT), 
Pin(3, Pin.OUT),
Pin(4, Pin.OUT),
Pin(5, Pin.OUT),
Pin(6, Pin.OUT)]

valled = (TENS - 0.1) / DIM
conv_fact = TENS / (1 << 12)

while True:
  result = adc.read_u16()
  voltage = result * conv_fact
  accensione = voltage / valled / 16.42

  n_led = accensione

  for k in range(len(Led)):
    Led[k].value(1 if k < n_led else 0)
